<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}
?>

<h2>Welcome, Admin!</h2>

<nav>
  <a href="manage_programmes.php">Manage Programmes</a> |
  <a href="view_interests.php">View Student Interests</a> |
  <a href="logout.php" style="color:red;">Logout</a>
</nav>
